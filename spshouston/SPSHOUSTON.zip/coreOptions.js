var filesMetaData = require('./filesMetaData.js');

module.exports = {
    siteUrl: "https://bandrdev.sharepoint.com",
    notification: true,
    checkin: false,
    checkinType: 2,
    filesMetaData: filesMetaData
}