module.exports = {
    username: "tdaly@company.onmicrosoft.com",
    password: "password123"
}